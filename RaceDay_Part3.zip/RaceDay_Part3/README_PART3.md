# RaceDay – Part 3 MVC Web Application

This solution extends the RaceDay Part 2 ASP.NET Core REST API with an ASP.NET Core MVC user interface. The MVC project communicates with the API through `RaceDayApiClient`; it does not connect directly to SQL Server.

## Solution structure
- `RaceDay.API` – REST API, EF Core data access, cookie authentication, role authorization and Azure Blob Storage uploads.
- `RaceDay.MVC` – responsive MVC interface for event browsing, registration/login, organiser tools and participant tools.
- `RaceDay.Tests` – automated test project carried forward from Part 2.
- `.github/workflows/dotnet.yml` – restore, build and test workflow for .NET 8.

## Features included
### Public / participant
- Browse events and view event details and categories.
- Register and log in through the Part 2 API.
- Enrol in an event category.
- View personal enrolments and results.
- Update profile details and upload a profile picture through the API.

### Organiser
- Organiser dashboard lists only events created by the signed-in organiser.
- Create, edit and delete events.
- Upload event banners; API stores the URL in the `EventImages` table.
- Add and delete event categories. Categories with enrolments cannot be deleted.
- View event enrolments and record/update finish times, positions and result statuses.

## Requirements
- Visual Studio 2022 (17.8 or later) with the .NET 8 SDK.
- SQL Server LocalDB for local API development.
- Azure Storage account connection string for image uploads.
- Docker Desktop for container testing (optional).

## Database update required
The MVC additions store a participant profile picture URL on the API `Users` record. If your Part 2 database already exists, run this once in SQL Server Management Studio against `RaceDayDb`:

```sql
IF COL_LENGTH('dbo.Users', 'ProfileImageUrl') IS NULL
    ALTER TABLE dbo.Users ADD ProfileImageUrl nvarchar(500) NULL;
```

If your database uses a different schema/table name, adjust the script to match your Part 2 database. Back up your database before schema changes.

## Run locally in Visual Studio 2022
1. Extract the ZIP and open `RaceDay.sln`.
2. Confirm the API connection string in `RaceDay.API/appsettings.json` points to your SQL Server LocalDB database.
3. Configure Azure Blob Storage using User Secrets (do not commit the connection string):

```powershell
dotnet user-secrets init --project RaceDay.API
dotnet user-secrets set "AzureBlobStorage:ConnectionString" "YOUR_AZURE_STORAGE_CONNECTION_STRING" --project RaceDay.API
```

4. Run the API project and note its HTTPS address from Visual Studio.
5. Set `ApiSettings:BaseUrl` in `RaceDay.MVC/appsettings.json` to that exact address with a trailing slash.
6. In Visual Studio, open **Solution Properties → Startup Project → Multiple startup projects** and set both `RaceDay.API` and `RaceDay.MVC` to **Start**. Start the solution.
7. Register a Participant and an Organiser account, then test each role.

## Azure Blob Storage
The API owns all blob operations. MVC posts multipart form data using the `file` field to:
- `POST /api/uploads/events/{eventId}/banner` (Organiser) – uploads a banner and saves its URL in `EventImages`.
- `POST /api/uploads/profile-picture` (Participant) – uploads a profile picture and saves its URL on the user profile.

Accepted file extensions: JPG, JPEG, PNG and WEBP; maximum size 5 MB. The supplied Blob Storage service creates private containers. A private blob URI is not automatically publicly viewable; configure an appropriate secure read mechanism (for example, short-lived read SAS URLs) before demonstrating images in a browser. Do not enable anonymous public access unless your institution/project explicitly permits it.

## Docker
Build the MVC container from the solution root:

```bash
docker build -t raceday-mvc -f RaceDay.MVC/Dockerfile .
```

Run it (replace the API URL with an address reachable from the container):

```bash
docker run --rm -p 8080:8080 -e ApiSettings__BaseUrl=http://host.docker.internal:7001/ raceday-mvc
```

The API must be running and reachable. LocalDB is Windows-only and is not available inside a Linux container; keep SQL Server/API running on the host or use a reachable SQL Server instance. The example URL/port is illustrative—use the actual API port and ensure HTTP/HTTPS certificate trust is configured.

## CI workflow
GitHub Actions restores, builds and tests the solution on pushes and pull requests. Review the Actions tab after pushing. Do not claim a successful CI run until GitHub reports it green.

## Before submission – verification checklist
- [ ] Build the complete solution in Visual Studio 2022 using Release configuration.
- [ ] Run all tests and record the results.
- [ ] Confirm API login cookies are forwarded by the MVC client.
- [ ] Test access restrictions for both roles and confirm logout clears the session.
- [ ] Test event CRUD, categories, enrolments, results and profile updates.
- [ ] Configure Azure Blob Storage and verify uploaded images can be read using the chosen secure access method.
- [ ] Build and run the Docker image with the API reachable from the container.
- [ ] Push at least 20 meaningful commits over the development process; do not fabricate commit history.
- [ ] Record the required demonstration video with your own voiceover and submit the GitHub repository link via ARC.

**Build/test status:** This workspace does not have the .NET SDK installed, so this package has not been compiled or run here. It is an updated project source package, not a claim of independently verified, submission-ready software. Complete the checklist above in Visual Studio and resolve any environment-specific errors before submission.
