using System.Net;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;

namespace RaceDay.MVC.Services;

public class RaceDayApiClient(HttpClient http)
{
    private static readonly JsonSerializerOptions JsonOptions = new(JsonSerializerDefaults.Web);

    private static void AddApiCookie(HttpRequestMessage request, HttpContext context)
    {
        var cookie = context.Session.GetString("ApiAuthCookie");
        if (!string.IsNullOrWhiteSpace(cookie))
            request.Headers.TryAddWithoutValidation("Cookie", cookie);
    }

    private static void CaptureApiCookie(HttpResponseMessage response, HttpContext context)
    {
        if (response.Headers.TryGetValues("Set-Cookie", out var values))
        {
            var auth = values.FirstOrDefault(v => v.StartsWith(".RaceDay.Auth=", StringComparison.Ordinal));
            if (auth != null) context.Session.SetString("ApiAuthCookie", auth.Split(';')[0]);
        }
    }

    public async Task<T?> GetAsync<T>(string path, HttpContext context)
    {
        using var req = new HttpRequestMessage(HttpMethod.Get, path);
        AddApiCookie(req, context);
        using var res = await http.SendAsync(req);
        if (!res.IsSuccessStatusCode) return default;
        return await res.Content.ReadFromJsonAsync<T>(JsonOptions);
    }

    public async Task<HttpResponseMessage> SendAsync(HttpMethod method, string path, object? body, HttpContext context)
    {
        var req = new HttpRequestMessage(method, path);
        AddApiCookie(req, context);
        if (body != null)
            req.Content = new StringContent(JsonSerializer.Serialize(body, JsonOptions), Encoding.UTF8, "application/json");
        var res = await http.SendAsync(req);
        CaptureApiCookie(res, context);
        return res;
    }

    public async Task<HttpResponseMessage> UploadAsync(string path, IFormFile file, HttpContext context)
    {
        var req = new HttpRequestMessage(HttpMethod.Post, path);
        AddApiCookie(req, context);
        var form = new MultipartFormDataContent();
        var stream = file.OpenReadStream();
        var part = new StreamContent(stream);
        part.Headers.ContentType = new MediaTypeHeaderValue(file.ContentType);
        form.Add(part, "file", file.FileName);
        req.Content = form;
        var res = await http.SendAsync(req);
        CaptureApiCookie(res, context);
        return res;
    }
}
