using Microsoft.AspNetCore.Mvc;
using RaceDay.MVC.Models;
using RaceDay.MVC.Services;
namespace RaceDay.MVC.Controllers;
public class AuthController(RaceDayApiClient api) : Controller {
    [HttpGet] public IActionResult Login() => View();
    [HttpPost, ValidateAntiForgeryToken] public async Task<IActionResult> Login(LoginVm vm) {
        if (!ModelState.IsValid) return View(vm);
        var res = await api.SendAsync(HttpMethod.Post, "api/auth/login", vm, HttpContext);
        if (!res.IsSuccessStatusCode) { ModelState.AddModelError("", "Login failed. Check your details and ensure the API is running."); return View(vm); }
        var data = await res.Content.ReadFromJsonAsync<LoginResponse>();
        HttpContext.Session.SetString("Role", data?.Role ?? "");
        HttpContext.Session.SetString("DisplayName", $"{data?.FirstName} {data?.LastName}".Trim());
        HttpContext.Session.SetInt32("UserId", data?.UserId ?? 0);
        return RedirectToAction("Index", data?.Role == "Organiser" ? "Organiser" : "Participant");
    }
    [HttpGet] public IActionResult Register() => View();
    [HttpPost, ValidateAntiForgeryToken] public async Task<IActionResult> Register(RegisterVm vm) {
        if (!ModelState.IsValid) return View(vm);
        var res = await api.SendAsync(HttpMethod.Post, "api/auth/register", vm, HttpContext);
        if (!res.IsSuccessStatusCode) { ModelState.AddModelError("", "Registration failed. The email may already be registered."); return View(vm); }
        TempData["Notice"] = "Account created. Please log in.";
        return RedirectToAction(nameof(Login));
    }
    [HttpPost, ValidateAntiForgeryToken] public async Task<IActionResult> Logout() {
        await api.SendAsync(HttpMethod.Post, "api/auth/logout", new { }, HttpContext);
        HttpContext.Session.Clear();
        return RedirectToAction("Index", "Home");
    }
    private record LoginResponse(int UserId, string FirstName, string LastName, string Email, string Role);
}
