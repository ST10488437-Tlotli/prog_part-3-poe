using Microsoft.AspNetCore.Mvc;
using RaceDay.MVC.Models;
using RaceDay.MVC.Services;
namespace RaceDay.MVC.Controllers;
public class OrganiserController(RaceDayApiClient api) : Controller {
    private bool IsOrganiser => HttpContext.Session.GetString("Role") == "Organiser";
    public async Task<IActionResult> Index() {
        if (!IsOrganiser) return RedirectToAction("Login", "Auth");
        var rows = await api.GetAsync<List<EventRow>>("api/events/mine", HttpContext) ?? new();
        return View(rows);
    }
    public IActionResult Create() => IsOrganiser ? View(new EventVm()) : RedirectToAction("Login", "Auth");
    [HttpPost, ValidateAntiForgeryToken] public async Task<IActionResult> Create(EventVm vm, IFormFile? banner) {
        if (!IsOrganiser) return Forbid();
        if (!ModelState.IsValid) return View(vm);
        var res = await api.SendAsync(HttpMethod.Post, "api/events", vm, HttpContext);
        if (!res.IsSuccessStatusCode) { ModelState.AddModelError("", "Could not create event. Check the API and your permissions."); return View(vm); }
        var created = await res.Content.ReadFromJsonAsync<CreatedEvent>();
        if (created != null && banner is { Length: > 0 })
            await api.UploadAsync($"api/uploads/events/{created.EventId}/banner", banner, HttpContext);
        return RedirectToAction(nameof(Index));
    }
    public async Task<IActionResult> Edit(int id) {
        if (!IsOrganiser) return RedirectToAction("Login", "Auth");
        var vm = await api.GetAsync<EventVm>($"api/events/{id}", HttpContext);
        return vm == null ? NotFound() : View(vm);
    }
    [HttpPost, ValidateAntiForgeryToken] public async Task<IActionResult> Edit(int id, EventVm vm, IFormFile? banner) {
        if (!IsOrganiser) return Forbid();
        if (!ModelState.IsValid) return View(vm);
        var res = await api.SendAsync(HttpMethod.Put, $"api/events/{id}", vm, HttpContext);
        if (!res.IsSuccessStatusCode) { ModelState.AddModelError("", "Could not update event."); return View(vm); }
        if (banner is { Length: > 0 }) await api.UploadAsync($"api/uploads/events/{id}/banner", banner, HttpContext);
        return RedirectToAction(nameof(Index));
    }
    [HttpPost, ValidateAntiForgeryToken] public async Task<IActionResult> Delete(int id) {
        if (!IsOrganiser) return Forbid();
        await api.SendAsync(HttpMethod.Delete, $"api/events/{id}", null, HttpContext);
        return RedirectToAction(nameof(Index));
    }
    public async Task<IActionResult> Enrolments(int id) {
        if (!IsOrganiser) return RedirectToAction("Login", "Auth");
        var rows = await api.GetAsync<List<EnrolmentRow>>($"api/events/{id}/enrolments", HttpContext) ?? new();
        return View(rows);
    }
    public async Task<IActionResult> Categories(int id) {
        if (!IsOrganiser) return RedirectToAction("Login", "Auth");
        ViewBag.EventId = id; ViewBag.EventName = (await api.GetAsync<EventNameVm>($"api/events/{id}", HttpContext))?.EventName ?? "Event";
        var rows = await api.GetAsync<List<CategoryVm>>($"api/events/{id}/categories", HttpContext) ?? new(); return View(rows);
    }
    [HttpPost, ValidateAntiForgeryToken] public async Task<IActionResult> AddCategory(int id, CategoryVm vm) {
        if (!IsOrganiser) return Forbid(); if (!ModelState.IsValid) { TempData["Error"] = "Enter valid category details."; return RedirectToAction(nameof(Categories), new { id }); }
        var res = await api.SendAsync(HttpMethod.Post, $"api/events/{id}/categories", vm, HttpContext); TempData[res.IsSuccessStatusCode ? "Notice" : "Error"] = res.IsSuccessStatusCode ? "Category added." : "Could not add category. Check for duplicate names."; return RedirectToAction(nameof(Categories), new { id });
    }
    [HttpPost, ValidateAntiForgeryToken] public async Task<IActionResult> DeleteCategory(int id, int categoryId) {
        if (!IsOrganiser) return Forbid(); var res = await api.SendAsync(HttpMethod.Delete, $"api/categories/{categoryId}", null, HttpContext); TempData[res.IsSuccessStatusCode ? "Notice" : "Error"] = res.IsSuccessStatusCode ? "Category deleted." : "This category may already have enrolments and cannot be deleted."; return RedirectToAction(nameof(Categories), new { id });
    }
    public async Task<IActionResult> Results(int id) {
        if (!IsOrganiser) return RedirectToAction("Login", "Auth"); ViewBag.EventId = id; ViewBag.EventName = (await api.GetAsync<EventNameVm>($"api/events/{id}", HttpContext))?.EventName ?? "Event";
        var rows = await api.GetAsync<List<EventResultVm>>($"api/events/{id}/results", HttpContext) ?? new(); ViewBag.Enrolments = await api.GetAsync<List<EnrolmentRow>>($"api/events/{id}/enrolments", HttpContext) ?? new(); return View(rows);
    }
    [HttpPost, ValidateAntiForgeryToken] public async Task<IActionResult> SaveResult(int id, int enrolmentId, string? finishTime, int? position, string resultStatus = "Finished") {
        if (!IsOrganiser) return Forbid(); TimeSpan? time = TimeSpan.TryParse(finishTime, out var parsed) ? parsed : null;
        var body = new { FinishTime = time, Position = position, ResultStatus = resultStatus };
        var existing = await api.GetAsync<List<EventResultVm>>($"api/events/{id}/results", HttpContext) ?? new(); var found = existing.FirstOrDefault(x => x.EnrolmentId == enrolmentId);
        var res = found == null ? await api.SendAsync(HttpMethod.Post, $"api/results?enrolmentId={enrolmentId}", body, HttpContext) : await api.SendAsync(HttpMethod.Put, $"api/results/{found.ResultId}", body, HttpContext);
        TempData[res.IsSuccessStatusCode ? "Notice" : "Error"] = res.IsSuccessStatusCode ? "Result saved." : "Could not save result. Check the time, position and enrolment."; return RedirectToAction(nameof(Results), new { id });
    }
    private record EventNameVm(string EventName);
    public record CategoryVm(int CategoryId, int EventId, string CategoryName, decimal DistanceKm, decimal EntryFee, int? MaximumParticipants);
    public record EventResultVm(int ResultId, int EnrolmentId, TimeSpan? FinishTime, int? Position, string ResultStatus);
    private record EventRow(int EventId, string EventName, DateTime EventDate, string Location, string EventType, decimal DistanceKm, string Status);
    private record CreatedEvent(int EventId);
    public record EnrolmentRow(int EnrolmentId, int ParticipantId, string ParticipantName, string CategoryName, string RaceNumber, string Status);
}
