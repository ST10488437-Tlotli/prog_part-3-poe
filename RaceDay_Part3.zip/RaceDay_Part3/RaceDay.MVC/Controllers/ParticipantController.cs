using Microsoft.AspNetCore.Mvc;
using RaceDay.MVC.Services;
namespace RaceDay.MVC.Controllers;
public class ParticipantController(RaceDayApiClient api) : Controller {
    private bool IsParticipant => HttpContext.Session.GetString("Role") == "Participant";
    public IActionResult Index() => IsParticipant ? View() : RedirectToAction("Login", "Auth");
    public async Task<IActionResult> Enrolments() {
        if (!IsParticipant) return RedirectToAction("Login", "Auth");
        var rows = await api.GetAsync<List<EnrolmentRow>>("api/enrolments/my", HttpContext) ?? new();
        return View(rows);
    }
    public async Task<IActionResult> Results() {
        if (!IsParticipant) return RedirectToAction("Login", "Auth");
        var rows = await api.GetAsync<List<ResultRow>>("api/results/my", HttpContext) ?? new();
        return View(rows);
    }
    public async Task<IActionResult> Profile() { if (!IsParticipant) return RedirectToAction("Login", "Auth"); var vm = await api.GetAsync<ProfileVm>("api/users/profile", HttpContext); return vm == null ? View(new ProfileVm()) : View(vm); }
    [HttpPost, ValidateAntiForgeryToken] public async Task<IActionResult> Profile(ProfileVm vm, IFormFile? picture) {
        if (!IsParticipant) return Forbid(); if (!ModelState.IsValid) return View(vm);
        if (picture is { Length: > 0 }) { var upload = await api.UploadAsync("api/uploads/profile-picture", picture, HttpContext); if (!upload.IsSuccessStatusCode) { ModelState.AddModelError("", "Profile picture upload failed. Check Azure Blob Storage settings and image format."); return View(vm); } var data = await upload.Content.ReadFromJsonAsync<UploadResponse>(); vm.ProfileImageUrl = data?.ImageUrl; }
        var res = await api.SendAsync(HttpMethod.Put, "api/users/profile", vm, HttpContext); TempData[res.IsSuccessStatusCode ? "Notice" : "Error"] = res.IsSuccessStatusCode ? "Profile updated." : "Could not update profile."; return RedirectToAction(nameof(Profile));
    }
    public class ProfileVm { [System.ComponentModel.DataAnnotations.Required] public string FirstName {get;set;} = ""; [System.ComponentModel.DataAnnotations.Required] public string LastName {get;set;} = ""; public string? PhoneNumber {get;set;} public string? ProfileImageUrl {get;set;} }
    private record UploadResponse(string ImageUrl);
    public record EnrolmentRow(int EnrolmentId, string EventName, string CategoryName, string RaceNumber, string Status, DateTime EnrolmentDate);
    public record ResultRow(int ResultId, string EventName, string CategoryName, TimeSpan? FinishTime, int? Position, string ResultStatus, DateTime RecordedAt);
}
