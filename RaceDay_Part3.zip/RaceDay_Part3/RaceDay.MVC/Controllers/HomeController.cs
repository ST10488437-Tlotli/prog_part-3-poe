using Microsoft.AspNetCore.Mvc;
using RaceDay.MVC.Services;
namespace RaceDay.MVC.Controllers;
public class HomeController(RaceDayApiClient api) : Controller {
    public async Task<IActionResult> Index() {
        var events = await api.GetAsync<List<EventCard>>("api/events", HttpContext) ?? new();
        return View(events);
    }
    public IActionResult Error() => View();
    public record EventCard(int EventId, string EventName, string? Description, DateTime EventDate, string Location, string EventType, decimal DistanceKm, string Status);
}
