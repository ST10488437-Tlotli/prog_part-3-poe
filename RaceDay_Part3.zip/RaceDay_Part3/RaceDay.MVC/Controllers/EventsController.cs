using Microsoft.AspNetCore.Mvc;
using RaceDay.MVC.Services;
namespace RaceDay.MVC.Controllers;
public class EventsController(RaceDayApiClient api) : Controller {
    public async Task<IActionResult> Details(int id) {
        var item = await api.GetAsync<EventDetails>($"api/events/{id}", HttpContext);
        if (item == null) return NotFound();
        ViewBag.Categories = await api.GetAsync<List<CategoryCard>>($"api/events/{id}/categories", HttpContext) ?? new();
        return View(item);
    }
    [HttpPost, ValidateAntiForgeryToken] public async Task<IActionResult> Enrol(int categoryId) {
        if (HttpContext.Session.GetString("Role") != "Participant") return RedirectToAction("Login", "Auth");
        var res = await api.SendAsync(HttpMethod.Post, "api/enrolments", new { CategoryId = categoryId }, HttpContext);
        TempData["Notice"] = res.IsSuccessStatusCode ? "Your enrolment has been submitted." : "Enrolment failed. Please check the event and try again.";
        return RedirectToAction("Enrolments", "Participant");
    }
    public record CategoryCard(int CategoryId, string CategoryName, decimal DistanceKm, decimal EntryFee, int? MaximumParticipants);
    public record EventDetails(int EventId, string EventName, string? Description, DateTime EventDate, string Location, string EventType, decimal DistanceKm, string? RouteInformation, string Status);
}
