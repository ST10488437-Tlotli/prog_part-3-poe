using System.ComponentModel.DataAnnotations;
namespace RaceDay.MVC.Models;

public class RegisterVm {
    [Required] public string FirstName { get; set; } = "";
    [Required] public string LastName { get; set; } = "";
    [Required, EmailAddress] public string Email { get; set; } = "";
    [Required, MinLength(8), DataType(DataType.Password)] public string Password { get; set; } = "";
    [Required] public string Role { get; set; } = "Participant";
    public string? PhoneNumber { get; set; }
}
public class LoginVm {
    [Required, EmailAddress] public string Email { get; set; } = "";
    [Required, DataType(DataType.Password)] public string Password { get; set; } = "";
}
public class EventVm {
    public int EventId { get; set; }
    [Required, MaxLength(150)] public string EventName { get; set; } = "";
    public string? Description { get; set; }
    [Required] public DateTime EventDate { get; set; } = DateTime.Today.AddDays(14);
    [Required] public string Location { get; set; } = "";
    [Required] public string EventType { get; set; } = "Run";
    [Range(0.1, 1000)] public decimal DistanceKm { get; set; } = 5;
    public string? RouteInformation { get; set; }
    public string Status { get; set; } = "Open";
}
