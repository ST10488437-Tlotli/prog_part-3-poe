# RaceDay Part 3

See [README_PART3.md](README_PART3.md) for setup, features, Docker instructions and the pre-submission verification checklist.
