using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using RaceDay.API.Data;
using RaceDay.API.Services;
namespace RaceDay.API.Controllers;
[ApiController]
[Route("api/uploads")]
[Authorize]
public class UploadsController(BlobStorageService storage, RaceDayDbContext db) : ControllerBase
{
    private int UserId => int.TryParse(User.FindFirstValue(ClaimTypes.NameIdentifier), out var id) ? id : 0;
    private static IActionResult? ValidateImage(IFormFile? file)
    {
        if (file == null || file.Length == 0) return new BadRequestObjectResult(new { message = "Select an image." });
        var ext = Path.GetExtension(file.FileName).ToLowerInvariant();
        if (file.Length > 5_000_000 || !new[] { ".jpg", ".jpeg", ".png", ".webp" }.Contains(ext)) return new BadRequestObjectResult(new { message = "Use JPG, PNG or WEBP images up to 5 MB." });
        return null;
    }
    [HttpPost("events/{eventId:int}/banner")]
    [Authorize(Roles="Organiser")]
    [RequestSizeLimit(5_000_000)]
    public async Task<IActionResult> EventBanner(int eventId, [FromForm] IFormFile file, CancellationToken ct)
    {
        var invalid = ValidateImage(file); if (invalid != null) return invalid;
        var ev = await db.Events.SingleOrDefaultAsync(x => x.EventId == eventId && x.OrganiserId == UserId, ct);
        if (ev == null) return NotFound(new { message = "Event not found." });
        try {
            var url = await storage.UploadAsync(file!, "event-banners", ct);
            db.EventImages.Add(new RaceDay.API.Models.EventImage { EventId = eventId, ImageUrl = url, BlobName = Path.GetFileName(new Uri(url).AbsolutePath) });
            await db.SaveChangesAsync(ct);
            return Ok(new { imageUrl = url });
        } catch (InvalidOperationException ex) { return StatusCode(503, new { message = ex.Message }); }
    }
    [HttpPost("profile-picture")]
    [Authorize(Roles="Participant")]
    [RequestSizeLimit(5_000_000)]
    public async Task<IActionResult> ProfilePicture([FromForm] IFormFile file, CancellationToken ct)
    {
        var invalid = ValidateImage(file); if (invalid != null) return invalid;
        var user = await db.Users.FindAsync(new object[] { UserId }, ct); if (user == null) return NotFound();
        try { user.ProfileImageUrl = await storage.UploadAsync(file!, "profile-pictures", ct); await db.SaveChangesAsync(ct); return Ok(new { imageUrl = user.ProfileImageUrl }); }
        catch (InvalidOperationException ex) { return StatusCode(503, new { message = ex.Message }); }
    }
}
