using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
namespace RaceDay.API.Services;
public class BlobStorageService(IConfiguration configuration) {
    public async Task<string> UploadAsync(IFormFile file, string containerName, CancellationToken cancellationToken = default) {
        var connection = configuration["AzureBlobStorage:ConnectionString"];
        if (string.IsNullOrWhiteSpace(connection)) throw new InvalidOperationException("Azure Blob Storage is not configured. Set AzureBlobStorage:ConnectionString.");
        var service = new BlobServiceClient(connection);
        var container = service.GetBlobContainerClient(containerName);
        await container.CreateIfNotExistsAsync(PublicAccessType.None, cancellationToken: cancellationToken);
        var safeName = $"{Guid.NewGuid():N}{Path.GetExtension(Path.GetFileName(file.FileName))}";
        var blob = container.GetBlobClient(safeName);
        await using var stream = file.OpenReadStream();
        await blob.UploadAsync(stream, new BlobHttpHeaders { ContentType = file.ContentType }, cancellationToken: cancellationToken);
        return blob.Uri.ToString();
    }
}
